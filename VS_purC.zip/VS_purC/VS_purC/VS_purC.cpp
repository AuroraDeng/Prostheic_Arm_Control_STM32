﻿// VS_purC.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include "pch.h"
#include <iostream>

#include  <stdio.h>
#include  <stdlib.h>
//#include  <unistd.h>
#include <Windows.h>
#include  <sys/types.h>
//#include  <sys/signal.h>
#include  <sys/stat.h>
#include  <fcntl.h>
//#include  <termios.h>
#include  <errno.h>
#include  <limits.h>
#include  <string.h>
#include  <time.h>
#include  <deque>

int main(int argc, char *argv[])
{
	std::deque<unsigned char> receiveddata;
	unsigned char    data[27];
	unsigned char t[4];
	union xxx { char m[4]; float n; }z;
	float   Force[6];
	HANDLE SerialHandle;

	SerialHandle = CreateFile(TEXT("COM4"),//COM口名字
		GENERIC_READ | GENERIC_WRITE,//允许读和写
		0,//独占方式
		NULL,
		OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL,
		NULL);
	if (SerialHandle == INVALID_HANDLE_VALUE)
	{
		printf("打开COM失败!\n");
		return -1;
	}
	SetupComm(SerialHandle, 1024, 1024);
	DCB serialdcb;
	GetCommState(SerialHandle, &serialdcb);
	serialdcb.BaudRate = 460800;
	serialdcb.ByteSize = 8;
	serialdcb.Parity = NOPARITY;
	serialdcb.StopBits = ONESTOPBIT;
	SetCommState(SerialHandle, &serialdcb);
	COMMTIMEOUTS SerialTimeOuts;
	SerialTimeOuts.ReadIntervalTimeout = MAXDWORD;//读间隔超时
	SerialTimeOuts.ReadTotalTimeoutMultiplier = 0;//读时间系数
	SerialTimeOuts.ReadTotalTimeoutConstant = 0;//读时间常量
	SerialTimeOuts.WriteTotalTimeoutMultiplier = 1;//写时间系数
	SerialTimeOuts.WriteTotalTimeoutConstant = 1;//写时间常量
	SetCommTimeouts(SerialHandle, &SerialTimeOuts); //设置超时
	//wirte command
	char writedata[10] = { 0 };
	writedata[0] = 0x48;
	writedata[1] = 0xAA;
	writedata[2] = 0x0D;
	writedata[3] = 0x0A;
	int len = 0, total_len = 0;

	DWORD dwBytesWrite, dwBytesToWrite;
	dwBytesToWrite = 4;
	WriteFile(SerialHandle, writedata, dwBytesToWrite, &dwBytesWrite, NULL);
	//read and deal
	unsigned char readdata[150];
	memset(readdata, 0, 150);//the length//////////////////////////////
	int max_fd = 0;
	fd_set readset = { 0 };
	struct timeval tv = { 0 };
	int i;
	int ReceivedDataLangth;
	DWORD wCount, ReadedwCount;
	wCount = 150;
	while (1)
	{
		ReadedwCount = 0;

		ReadFile(SerialHandle, readdata, wCount, &ReadedwCount, NULL);
		if(ReadedwCount > 0)
		{
			for (i = 0; i < ReadedwCount; i++)
				receiveddata.push_back(readdata[i]);
		}
		while (receiveddata.size() > 0)
		{
			ReceivedDataLangth = receiveddata.size();  //缓存目前收到数据的长度，以免循环过程中有新数据写入或读出影响操作
			if ((ReceivedDataLangth >= 28) && (receiveddata.at(26) == 0x0d) && (receiveddata.at(27) == 0x0a))
			{
				for (i = 0; i < 28; i++)
				{
					data[i] = receiveddata.front();
					receiveddata.pop_front();
				}
				for (i = 0; i < 4; i++)
				{
					z.m[i] = data[i + 2];
				}
				Force[0] = z.n;
				for (i = 0; i < 4; i++)
				{
					z.m[i] = data[i + 6];
				}
				Force[1] = z.n;
				for (i = 0; i < 4; i++)
				{
					z.m[i] = data[i + 10];
				}
				Force[2] = z.n;
				for (i = 0; i < 4; i++)
				{
					z.m[i] = data[i + 14];
				}
				Force[3] = z.n;
				for (i = 0; i < 4; i++)
				{
					z.m[i] = data[i + 18];
				}
				Force[4] = z.n;
				for (i = 0; i < 4; i++)
				{
					z.m[i] = data[i + 22];
				}
				Force[5] = z.n;
				printf("Fx= %2f Kg,Fy= %2f Kg,Fz= %2f Kg,Mx= %2f Kg/M,My= %2f Kg/M,Mz= %2f Kg/M\n", Force[0], Force[1], Force[2], Force[3], Force[4], Force[5]);
			}
			else if ((ReceivedDataLangth >= 28) && (ReceivedDataLangth < 120))
			{
				if (receiveddata.at(0) == 0x0a)
					receiveddata.pop_front();
				else
				{
					i = 0;
					while ((i <= ReceivedDataLangth-2) && (receiveddata.at(0) != 0x0d) && (receiveddata.at(1) != 0x0a))
					{
						receiveddata.pop_front();
						i++;
					}
					if (receiveddata.size() >= 2)
					{
						receiveddata.pop_front();
						receiveddata.pop_front();
					}
				}
			}
			else if (ReceivedDataLangth >= 120)
				receiveddata.clear();
			else if (ReceivedDataLangth < 28)
				break;
		}
	}

	return 0;
}

